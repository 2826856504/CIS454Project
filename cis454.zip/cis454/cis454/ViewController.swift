//
//  ViewController.swift
//  cis454
//
//  Created by 张尧 on 2/1/20.
//  Copyright © 2020 张尧. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Username: UITextField!
    @IBOutlet weak var Password: UITextField!
    
    @IBOutlet weak var Signbutton: UIButton!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func Loginbutton(_ sender: Any) {
    }
}

